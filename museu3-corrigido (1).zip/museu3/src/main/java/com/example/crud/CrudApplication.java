package com.example.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Ponto de entrada.
 *
 * Usuários criados na 1ª execução:
 *   admin   / admin123   → ADMIN
 *   biblio  / biblio123  → BIBLIOTECARIO
 *
 * Ver: com.example.crud.config.UserSeeder
 */
@SpringBootApplication(proxyBeanMethods = false)
public class CrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(CrudApplication.class, args);
    }
}
