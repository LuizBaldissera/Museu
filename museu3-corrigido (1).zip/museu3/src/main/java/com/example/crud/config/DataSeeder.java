package com.example.crud.config;

import com.example.crud.model.Autor;
import com.example.crud.model.Obra;
import com.example.crud.model.TipoObra;
import com.example.crud.repository.AutorRepository;
import com.example.crud.repository.ObraRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.util.*;

@Configuration
public class DataSeeder {

    @Bean
    CommandLineRunner seedObras(
            ObraRepository obraRepository,
            AutorRepository autorRepository) {

        return args -> {

            if (obraRepository.count() > 2) {
                System.out.println("Banco já populado.");
                return;
            }

            Random random = new Random();

            // ============================================================
            // 200 autores — nomes compostos únicos garantidos por índice
            // ============================================================
            String[] prenomes = {
                "Machado", "Clarice", "José", "Paulo", "Jorge",
                "Graciliano", "Monteiro", "George", "John", "Joanne",
                "Stephen", "Dan", "Isaac", "Agatha", "Arthur",
                "Carlos", "Ana", "Maria", "Pedro", "Lucas",
                "Felipe", "Rafael", "Bruno", "Fernanda", "Juliana",
                "Beatriz", "Gustavo", "Eduardo", "Renata", "Thiago"
            };

            String[] sobrenomes = {
                "Silva", "Souza", "Oliveira", "Costa", "Santos",
                "Ferreira", "Pereira", "Almeida", "Lima", "Rodrigues",
                "Assis", "Lispector", "Saramago", "Coelho", "Amado",
                "Ramos", "Lobato", "Orwell", "Tolkien", "Rowling",
                "King", "Brown", "Asimov", "Christie", "Doyle",
                "Nascimento", "Barbosa", "Carvalho", "Gomes", "Martins"
            };

            // Gera 200 combinações únicas de índice (não colisão garantida)
            Set<String> nomesUsados = new LinkedHashSet<>();
            List<Autor> autores = new ArrayList<>();

            outer:
            for (int p = 0; p < prenomes.length; p++) {
                for (int s = 0; s < sobrenomes.length; s++) {
                    String nome = prenomes[p] + " " + sobrenomes[s];
                    if (nomesUsados.contains(nome)) continue;
                    nomesUsados.add(nome);
                    Autor autor = autorRepository
                            .findByNomeIgnoreCase(nome)
                            .orElseGet(() -> autorRepository.save(new Autor(nome)));
                    autores.add(autor);
                    if (autores.size() == 200) break outer;
                }
            }

            System.out.println("Autores criados/encontrados: " + autores.size());

            // ============================================================
            // 3000 obras
            // ============================================================
            String[] categorias = {
                "Literatura", "Romance", "Ficção", "História",
                "Ciência", "Tecnologia", "Arte", "Educação",
                "Economia", "Esportes"
            };

            String[] locais = {
                "Estante A1", "Estante A2", "Estante B1",
                "Estante B2", "Estante C1", "Arquivo 1"
            };

            List<Obra> batch = new ArrayList<>(100);

            for (int i = 1; i <= 3000; i++) {

                Obra obra = new Obra();

                if (i <= 1000) {
                    obra.setTipoObra(TipoObra.LIVRO);
                    obra.setTitulo("Livro " + i);
                    obra.setIsbn(gerarISBN(random));
                    obra.setNumeroPaginas(100 + random.nextInt(400));

                } else if (i <= 2000) {
                    obra.setTipoObra(TipoObra.REVISTA);
                    obra.setTitulo("Revista " + (i - 1000));
                    obra.setIssn(gerarISSN(random));
                    obra.setNumeroPaginas(30 + random.nextInt(120));

                } else {
                    obra.setTipoObra(TipoObra.JORNAL);
                    obra.setTitulo("Jornal " + (i - 2000));
                    obra.setIssn(gerarISSN(random));
                    obra.setNumeroPaginas(20 + random.nextInt(80));
                }

                obra.setCategoria(categorias[random.nextInt(categorias.length)]);
                obra.setAnoPublicacao(1950 + random.nextInt(76));
                obra.setDataAquisicao(LocalDate.of(
                        2020 + random.nextInt(6),
                        1 + random.nextInt(12),
                        1 + random.nextInt(28)));
                obra.setDescricao("Descrição automática da obra " + i);
                obra.setImageUrl("https://picsum.photos/400?random=" + i);
                obra.setLocalizacao(locais[random.nextInt(locais.length)]);

                // 1 a 3 autores por obra
                Set<Autor> escolhidos = new HashSet<>();
                int qtd = 1 + random.nextInt(3);
                while (escolhidos.size() < qtd) {
                    escolhidos.add(autores.get(random.nextInt(autores.size())));
                }
                obra.getAutores().addAll(escolhidos);

                obraRepository.save(obra);

                if (i % 500 == 0) {
                    System.out.println("  → " + i + " obras inseridas...");
                }
            }

            System.out.println("================================");
            System.out.println("Seeder finalizado!");
            System.out.println("200 autores criados");
            System.out.println("3000 obras criadas");
            System.out.println("================================");
        };
    }

    private String gerarISBN(Random random) {
        return "978" + (100000000 + random.nextInt(899999999));
    }

    private String gerarISSN(Random random) {
        return String.format("%04d-%04d",
                random.nextInt(10000),
                random.nextInt(10000));
    }
}
