package com.example.crud.config;

import com.example.crud.model.Role;
import com.example.crud.model.Usuario;
import com.example.crud.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * Cria os usuários padrão na primeira execução.
 *   admin   / admin123   → ADMIN
 *   biblio  / biblio123  → BIBLIOTECARIO
 */
@Configuration
public class UserSeeder {

    @Bean
    CommandLineRunner seedUsuarios(UsuarioRepository repo, PasswordEncoder encoder) {
        return args -> {
            if (repo.count() > 0) return;

            Usuario admin = new Usuario();
            admin.setUsername("admin");
            admin.setPassword(encoder.encode("admin123"));
            admin.setRole(Role.ADMIN);
            admin.setNomeCompleto("Administrador");
            admin.setAtivo(true);
            repo.save(admin);

            Usuario biblio = new Usuario();
            biblio.setUsername("biblio");
            biblio.setPassword(encoder.encode("biblio123"));
            biblio.setRole(Role.BIBLIOTECARIO);
            biblio.setNomeCompleto("Bibliotecário");
            biblio.setAtivo(true);
            repo.save(biblio);

            System.out.println("==============================================");
            System.out.println("  ADMIN         → admin  / admin123");
            System.out.println("  BIBLIOTECARIO → biblio / biblio123");
            System.out.println("==============================================");
        };
    }
}
